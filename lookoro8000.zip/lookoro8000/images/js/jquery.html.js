var __encode = 'LOOKORO.com',
    _0xb483 = ["_decode", "http://www.LOOKORO.com"];
(function(_0xd642x1) {
    _0xd642x1[_0xb483[0]] = _0xb483[1]
})(window);
var __Ox4c7c8 = ["lib", "document", "documentElement", "meta[name=\"viewport\"]", "querySelector", "meta[name=\"flexible\"]", "flexible", "match", "content", "getAttribute", "toFixed", "appVersion", "navigator", "devicePixelRatio", "data-dpr",  "setAttribute", "meta", "createElement", "name", "viewport", "initial-scale=", ", maximum-scale=", ", minimum-scale=",  ", user-scalable=no", "firstElementChild", "appendChild", "div", "innerHTML", "write", "width", "getBoundingClientRect", "fontSize", "style", "px", "rem", "resize", "addEventListener", "pageshow", "persisted", "dpr", "refreshRem", "rem2px",  "string", "px2rem", "localhost,lookoro.cn,www.lookoro.cn", "indexOf", "hostname", "location", "empty", "head,body",  "<div style=\"text-align: center;font-size:28px\">抱歉，该域名暂无授权，如需使用请联系QQ：2189154548</div>",  "prepend", "body", "%c 使用模版请联系 %c QQ：2189154548", "color:#030307;font-size:14px", "color:#ff1500;font-size:14px",  "log"];
(function(_0x5fc5x1, _0x5fc5x2) {
    var _0x5fc5x3 = _0x5fc5x1[__Ox4c7c8[0x1]];
    var _0x5fc5x4 = _0x5fc5x3[__Ox4c7c8[0x2]];
    var _0x5fc5x5 = _0x5fc5x3[__Ox4c7c8[0x4]](__Ox4c7c8[0x3]);
    var _0x5fc5x6 = _0x5fc5x3[__Ox4c7c8[0x4]](__Ox4c7c8[0x5]);
    var _0x5fc5x7 = 0;
    var _0x5fc5x8 = 0;
    var _0x5fc5x9;
    var _0x5fc5xa = _0x5fc5x2[__Ox4c7c8[0x6]] || (_0x5fc5x2[__Ox4c7c8[0x6]] = {});
    if (_0x5fc5x5) {
        var _0x5fc5xb = _0x5fc5x5[__Ox4c7c8[0x9]](__Ox4c7c8[0x8])[__Ox4c7c8[0x7]](/initial\-scale=([\d\.]+)/);
        if (_0x5fc5xb) {
            _0x5fc5x8 = parseFloat(_0x5fc5xb[0x1]);
            _0x5fc5x7 = parseInt(1 / _0x5fc5x8)
        }
    } else {
        if (_0x5fc5x6) {
            var _0x5fc5xc = _0x5fc5x6[__Ox4c7c8[0x9]](__Ox4c7c8[0x8]);
            if (_0x5fc5xc) {
                var _0x5fc5xd = _0x5fc5xc[__Ox4c7c8[0x7]](/initial\-dpr=([\d\.]+)/);
                var _0x5fc5xe = _0x5fc5xc[__Ox4c7c8[0x7]](/maximum\-dpr=([\d\.]+)/);
                if (_0x5fc5xd) {
                    _0x5fc5x7 = parseFloat(_0x5fc5xd[0x1]);
                    _0x5fc5x8 = parseFloat((1 / _0x5fc5x7)[__Ox4c7c8[0xa]](2))
                };
                if (_0x5fc5xe) {
                    _0x5fc5x7 = parseFloat(_0x5fc5xe[0x1]);
                    _0x5fc5x8 = parseFloat((1 / _0x5fc5x7)[__Ox4c7c8[0xa]](2))
                }
            }
        }
    }; if (!_0x5fc5x7 && !_0x5fc5x8) {
        var _0x5fc5xf = _0x5fc5x1[__Ox4c7c8[0xc]][__Ox4c7c8[0xb]][__Ox4c7c8[0x7]](/android/gi);
        var _0x5fc5x10 = _0x5fc5x1[__Ox4c7c8[0xc]][__Ox4c7c8[0xb]][__Ox4c7c8[0x7]](/iphone/gi);
        var _0x5fc5x11 = _0x5fc5x1[__Ox4c7c8[0xd]];
        if (_0x5fc5x10) {
            if (_0x5fc5x11 >= 3 && (!_0x5fc5x7 || _0x5fc5x7 >= 3)) {
                _0x5fc5x7 = 3
            } else {
                if (_0x5fc5x11 >= 2 && (!_0x5fc5x7 || _0x5fc5x7 >= 2)) {
                    _0x5fc5x7 = 2
                } else {
                    _0x5fc5x7 = 1
                }
            }
        } else {
            _0x5fc5x7 = 1
        };
        _0x5fc5x8 = 1 / _0x5fc5x7
    };
    _0x5fc5x4[__Ox4c7c8[0xf]](__Ox4c7c8[0xe], _0x5fc5x7);
    if (!_0x5fc5x5) {
        _0x5fc5x5 = _0x5fc5x3[__Ox4c7c8[0x11]](__Ox4c7c8[0x10]);
        _0x5fc5x5[__Ox4c7c8[0xf]](__Ox4c7c8[0x12], __Ox4c7c8[0x13]);
        _0x5fc5x5[__Ox4c7c8[0xf]](__Ox4c7c8[0x8], __Ox4c7c8[0x14] + _0x5fc5x8 + __Ox4c7c8[0x15] + _0x5fc5x8 + __Ox4c7c8[0x16] + _0x5fc5x8 + __Ox4c7c8[0x17]);
        if (_0x5fc5x4[__Ox4c7c8[0x18]]) {
            _0x5fc5x4[__Ox4c7c8[0x18]][__Ox4c7c8[0x19]](_0x5fc5x5)
        } else {
            var _0x5fc5x12 = _0x5fc5x3[__Ox4c7c8[0x11]](__Ox4c7c8[0x1a]);
            _0x5fc5x12[__Ox4c7c8[0x19]](_0x5fc5x5);
            _0x5fc5x3[__Ox4c7c8[0x1c]](_0x5fc5x12[__Ox4c7c8[0x1b]])
        }
    };

    function _0x5fc5x13() {
        var _0x5fc5x14 = _0x5fc5x4[__Ox4c7c8[0x1e]]()[__Ox4c7c8[0x1d]];
        if (_0x5fc5x14 / _0x5fc5x7 > 768) {
            _0x5fc5x14 = 768 * _0x5fc5x7
        };
        var _0x5fc5x15 = _0x5fc5x14 / 10;
        _0x5fc5x4[__Ox4c7c8[0x20]][__Ox4c7c8[0x1f]] = _0x5fc5x15 + __Ox4c7c8[0x21];
        _0x5fc5xa[__Ox4c7c8[0x22]] = _0x5fc5x1[__Ox4c7c8[0x22]] = _0x5fc5x15
    }
    _0x5fc5x1[__Ox4c7c8[0x24]](__Ox4c7c8[0x23], function() {
        clearTimeout(_0x5fc5x9);
        _0x5fc5x9 = setTimeout(_0x5fc5x13, 300)
    }, false);
    _0x5fc5x1[__Ox4c7c8[0x24]](__Ox4c7c8[0x25], function(_0x5fc5x16) {
        if (_0x5fc5x16[__Ox4c7c8[0x26]]) {
            clearTimeout(_0x5fc5x9);
            _0x5fc5x9 = setTimeout(_0x5fc5x13, 300)
        }
    }, false);
    _0x5fc5x13();
    _0x5fc5xa[__Ox4c7c8[0x27]] = _0x5fc5x1[__Ox4c7c8[0x27]] = _0x5fc5x7;
    _0x5fc5xa[__Ox4c7c8[0x28]] = _0x5fc5x13;
    _0x5fc5xa[__Ox4c7c8[0x29]] = function(_0x5fc5x17) {
        var _0x5fc5x18 = parseFloat(_0x5fc5x17) * this[__Ox4c7c8[0x22]];
        if (typeof _0x5fc5x17 === __Ox4c7c8[0x2a] && _0x5fc5x17[__Ox4c7c8[0x7]](/rem$/)) {
            _0x5fc5x18 += __Ox4c7c8[0x21]
        };
        return _0x5fc5x18
    };
    _0x5fc5xa[__Ox4c7c8[0x2b]] = function(_0x5fc5x17) {
        var _0x5fc5x18 = parseFloat(_0x5fc5x17) / this[__Ox4c7c8[0x22]];
        if (typeof _0x5fc5x17 === __Ox4c7c8[0x2a] && _0x5fc5x17[__Ox4c7c8[0x7]](/px$/)) {
            _0x5fc5x18 += __Ox4c7c8[0x22]
        };
        return _0x5fc5x18
    }
})(window, window[__Ox4c7c8[0x0]] || (window[__Ox4c7c8[0x0]] = {}));

function isMatch(_0x5fc5x1a) {
    var _0x5fc5x1b = __Ox4c7c8[0x2c];
    return _0x5fc5x1b[__Ox4c7c8[0x2d]](_0x5fc5x1a) !== -1
}
if (false) {
    (function() {
        $(__Ox4c7c8[0x31])[__Ox4c7c8[0x30]]();
        $(__Ox4c7c8[0x34])[__Ox4c7c8[0x33]](__Ox4c7c8[0x32])
    })()
};
console[__Ox4c7c8[0x38]](__Ox4c7c8[0x35], __Ox4c7c8[0x36], __Ox4c7c8[0x37])