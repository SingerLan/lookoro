var __encode = 'lookoro.cn',
    _0xb483 = ["_decode", "http://www.lookoro.cn"];
(function(_0xd642x1) {
    _0xd642x1[_0xb483[0]] = _0xb483[1]
})(window);
var __Ox4c7c4 = ["localhost,www.lookoro.cn,lookoro.cn",
 "indexOf", "hostname", "location", "empty", "head,body", 
 "<div style=\"text - align: center; font - size: 28px \">抱歉，该域名暂无授权，如需使用请联系QQ：2189154548</div>",
 "prepend", "body", "URL", "domain", "title", "pathname", "toLowerCase", "browserLanguage", "language", "getContext",
 "canvas", "createElement", "userAgent", "match", "Android", "Linux", "iPhone", "Mac", "iPad", "Trident", "Presto", 
 "AppleWebKit", "Gecko", "KHTML", "MicroMessenger", "am-modal-active", "addClass", ".am-share", "length", ".sharebg", 
 "sharebg-active", "<div class=\"sharebg \"></div>", "append", "removeClass", ".sharebg-active", "remove", "click", 
 ".sharebg-active,.share_btn", ".open-share", "weixin", "useragent", "browser", 
 "<li><a rel=\"nofollow \" href=\"https: //mp.weixin.qq.com/mp/profile_ext?action=home&__biz=MzU4NTY2OTQ3Ng==&scene=126&bizpsid=0#wechat_redirect\" target=\"_blank\">小说</a></li>", 
 "after", "#xiao", "path", "https://cdn.bootcss.com/Swiper/3.4.2/js/swiper.min.js", 
 ".banner-top", ".swiper-button-prev", ".swiper-button-next", ")", "http://www.lookoro.cn", "replace", 
 "url(", "backgroundImage", "css", ".banner-top .swiper-slide-active a", "style", "bgimage", "getElementById", ".banner-wtop", 
 ".swiper-pagination", "run", "adaptiveBackground", ".art_banner", "getScript", "width", "overhidden", "html,body", "menu_block", ".all_menu", ".close_menu", ".menu", "show", "eq", "hide", "hover", "each", ".head_menu_b", "hash", "top", "offset", "animate", "scrollTop", "height", "nav_fixed", "#topnav,.listnow,.art_navlist", "scroll", "adfixed", ".ads_rbox", "search_btn", ".submit", "focus", "input.form_control", "blur", "/templets/lookoro8000/images/js/iscroll.js", "navbarscroll", ".wrapper", ".ik-n-01", "#ik01", ".ik-n-02", "#ik02", ".ik-n-03", "#ik03", ".ik-n-04", "#ik04", ".ik-n-05", "#ik05", ".ik-n-06", "#ik06", "slow", "slideToggle", ".panel", "toggle", ".xs1", ".xs2", ".flip", "#bottom_ads", "foot_stem", ".foot", ".close_ads_btn", "#fd_tips", ".close_tips", "#short", "#short2", "https://api.weibo.com/2/short_url/shorten.json", "val", "#app_key", "#shareurl", "?source=", "&url_long=", "url", "urlpath", "GET", "jsonp", "urls", "data", "url_short", "ajax", "https://cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js", "fadeIn", "lazyload", ".lazyload", ".list_scroll .vodlist_thumb", "boxload", ".vodlist_sm,.vodlist_sh", ".boxload", "https://cdn.bootcss.com/jquery.qrcode/1.0/jquery.qrcode.min.js", "qrcode", ".cans", "src", "image/png", "toDataURL", ".qrcode", "a.backtop", "display", "block", "none", "html, body", "on", "https://cdn.bootcss.com/clipboard.js/2.0.4/clipboard.min.js", "copy_btn", "getElementsByClassName", "success", "slideUp", "delay", "slideDown", "#show", "log", "error", "#wx_name", "#wx_qrcode", "#zans_qrcode", "<div class=\"ikan_wrap\"><div class=\"mac_pop_bg\"></div><div class=\"ikan_content\"><div class=\"ikan_content_hd\"><h4 class=\"ikan_content_title\">关注后微信观看</h4></div><div class=\"ikan_content_bd\"><img class=\"info_img\" src=\"", "\" alt=\"公众号二维码\"><p>长按识别二维码或微信扫码关注</p><p>关注后回复片名即可</p><p>或微信搜索微信名：<span style=\"color: #f44336;\">", "<span></p></div><div class=\"ikan_content_ft\"><a class=\"close_box\" href=\"javascript:;\">下次再说</a></div></div></div>", ".ikan_wrap", ".close_box,.mac_pop_bg", ".btn_wxgzh", "<div class=\"ikan_wrap\"><div class=\"mac_pop_bg\"></div><div class=\"ikan_content\"><div class=\"ikan_content_hd\"><h4 class=\"ikan_content_title\">感谢赞赏</h4></div><div class=\"ikan_content_bd\"><img class=\"info_img\" src=\"", "\" alt=\"赞赏二维码\"><p>长按识别二维码或微信扫描二维码</p>金额随意，多少都是支持</p></div><div class=\"ikan_content_ft\"><a class=\"ikan_btn_no\" href=\"javascript:;\">残忍拒绝</a><a class=\"close_box\" href=\"javascript:;\">取消</a></div></div></div>", "就知道你会点，哼~，不过还要祝你观影愉快～！", ".ikan_btn_no", ".btn_zhans", "mobile", "share", "xiaoshuo", "swiper", "menu", "fixed", "wrapper", "flip", "closebtn", "shorturl", "images", "scrolltop", "copy", "wxqrcode", "ready"];

function isMatch(_0x63d3x2) {
    var _0x63d3x3 = __Ox4c7c4[0x0];
    return _0x63d3x3[__Ox4c7c4[0x1]](_0x63d3x2) !== -1
}
if (false) {
    (function() {
        $(__Ox4c7c4[0x5])[__Ox4c7c4[0x4]]();
        $(__Ox4c7c4[0x8])[__Ox4c7c4[0x7]](__Ox4c7c4[0x6])
    })()
};
var ikan = {
    browser: {
        url: document[__Ox4c7c4[0x9]],
        domain: document[__Ox4c7c4[0xa]],
        title: document[__Ox4c7c4[0xb]],
        urlpath: document[__Ox4c7c4[0x3]][__Ox4c7c4[0xc]],
        language: (navigator[__Ox4c7c4[0xe]] || navigator[__Ox4c7c4[0xf]])[__Ox4c7c4[0xd]](),
        canvas: function() {
            return !!document[__Ox4c7c4[0x12]](__Ox4c7c4[0x11])[__Ox4c7c4[0x10]]
        }(),
        useragent: function() {
            var _0x63d3x5 = navigator[__Ox4c7c4[0x13]];
            return {
                mobile: !!_0x63d3x5[__Ox4c7c4[0x14]](/AppleWebKit.*Mobile.*/),
                ios: !!_0x63d3x5[__Ox4c7c4[0x14]](/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                android: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x15]) || -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x16]),
                iPhone: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x17]) || -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x18]),
                iPad: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x19]),
                trident: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1a]),
                presto: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1b]),
                webKit: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1c]),
                gecko: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1d]) && -1 === _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1e]),
                weixin: -1 < _0x63d3x5[__Ox4c7c4[0x1]](__Ox4c7c4[0x1f])
            }
        }()
    },
    mobile: {
        share: function() {
            $(__Ox4c7c4[0x2d])[__Ox4c7c4[0x2b]](function() {
                $(__Ox4c7c4[0x22])[__Ox4c7c4[0x21]](__Ox4c7c4[0x20]);
                if ($(__Ox4c7c4[0x24])[__Ox4c7c4[0x23]] > 0) {
                    $(__Ox4c7c4[0x24])[__Ox4c7c4[0x21]](__Ox4c7c4[0x25])
                } else {
                    $(__Ox4c7c4[0x8])[__Ox4c7c4[0x27]](__Ox4c7c4[0x26]);
                    $(__Ox4c7c4[0x24])[__Ox4c7c4[0x21]](__Ox4c7c4[0x25])
                };
                $(__Ox4c7c4[0x2c])[__Ox4c7c4[0x2b]](function() {
                    $(__Ox4c7c4[0x22])[__Ox4c7c4[0x28]](__Ox4c7c4[0x20]);
                    setTimeout(function() {
                        $(__Ox4c7c4[0x29])[__Ox4c7c4[0x28]](__Ox4c7c4[0x25]);
                        $(__Ox4c7c4[0x24])[__Ox4c7c4[0x2a]]()
                    }, 300)
                })
            })
        },
        xiaoshuo: function() {
            ikan[__Ox4c7c4[0x30]][__Ox4c7c4[0x2f]][__Ox4c7c4[0x2e]] ? $(__Ox4c7c4[0x33])[__Ox4c7c4[0x32]](__Ox4c7c4[0x31]) : $(__Ox4c7c4[0x33])[__Ox4c7c4[0x32]]()
        }
    },
    swiper: function() {
        $[__Ox4c7c4[0x48]](maccms[__Ox4c7c4[0x34]] + __Ox4c7c4[0x35], function() {
            var _0x63d3x6 = new Swiper(__Ox4c7c4[0x36], {
                autoplay: 5000,
                autoplayDisableOnInteraction: false,
                speed: 1000,
                loop: true,
                slidesPerView: 5,
                centeredSlides: true,
                mousewheelControl: true,
                prevButton: __Ox4c7c4[0x37],
                nextButton: __Ox4c7c4[0x38],
                lazyLoading: true,
                lazyLoadingInPrevNext: true,
                runCallbacksOnInit: false,
                onInit: function() {
                    setTimeout(function() {
                        var _0x63d3x7 = $(__Ox4c7c4[0x3f])[__Ox4c7c4[0x3e]](__Ox4c7c4[0x3d])[__Ox4c7c4[0x3b]](__Ox4c7c4[0x3c], __Ox4c7c4[0x3a])[__Ox4c7c4[0x3b]](__Ox4c7c4[0x39], __Ox4c7c4[0x3a]);
                        document[__Ox4c7c4[0x42]](__Ox4c7c4[0x41])[__Ox4c7c4[0x40]][__Ox4c7c4[0x3d]] = __Ox4c7c4[0x3c] + _0x63d3x7 + __Ox4c7c4[0x39]
                    }, 1500)
                },
                onSlideChangeStart: function() {
                    var _0x63d3x7 = $(__Ox4c7c4[0x3f])[__Ox4c7c4[0x3e]](__Ox4c7c4[0x3d])[__Ox4c7c4[0x3b]](__Ox4c7c4[0x3c], __Ox4c7c4[0x3a])[__Ox4c7c4[0x3b]](__Ox4c7c4[0x39], __Ox4c7c4[0x3a]);
                    document[__Ox4c7c4[0x42]](__Ox4c7c4[0x41])[__Ox4c7c4[0x40]][__Ox4c7c4[0x3d]] = __Ox4c7c4[0x3c] + _0x63d3x7 + __Ox4c7c4[0x39]
                },
                breakpoints: {
                    1024: {
                        slidesPerView: 4.6
                    },
                    820: {
                        slidesPerView: 2.5
                    }
                }
            });
            var _0x63d3x6 = new Swiper(__Ox4c7c4[0x43], {
                autoplay: 5000,
                autoplayDisableOnInteraction: false,
                loop: true,
                prevButton: __Ox4c7c4[0x37],
                nextButton: __Ox4c7c4[0x38],
                pagination: __Ox4c7c4[0x44],
                paginationClickable: true,
                onInit: function() {
                    setTimeout(function() {
                        $[__Ox4c7c4[0x46]][__Ox4c7c4[0x45]]()
                    }, 1500)
                }
            });
            var _0x63d3x6 = new Swiper(__Ox4c7c4[0x47], {
                autoplay: 5000,
                autoplayDisableOnInteraction: false,
                spaceBetween: 1,
                speed: 1000,
                slidesPerView: 1,
                loop: true,
                prevButton: __Ox4c7c4[0x37],
                nextButton: __Ox4c7c4[0x38],
                pagination: __Ox4c7c4[0x44],
                paginationClickable: true,
                lazyLoading: true,
                lazyLoadingInPrevNext: true
            })
        })
    },
    menu: function() {
        var _0x63d3x8 = $(window)[__Ox4c7c4[0x49]]();
        if (_0x63d3x8 < 820) {
            $(__Ox4c7c4[0x4f])[__Ox4c7c4[0x2b]](function() {
                $(__Ox4c7c4[0x4b])[__Ox4c7c4[0x21]](__Ox4c7c4[0x4a]);
                $(__Ox4c7c4[0x4d])[__Ox4c7c4[0x21]](__Ox4c7c4[0x4c]);
                $(__Ox4c7c4[0x4e])[__Ox4c7c4[0x2b]](function() {
                    $(__Ox4c7c4[0x4b])[__Ox4c7c4[0x28]](__Ox4c7c4[0x4a]);
                    $(__Ox4c7c4[0x4d])[__Ox4c7c4[0x28]](__Ox4c7c4[0x4c])
                })
            })
        } else {
            $(__Ox4c7c4[0x55])[__Ox4c7c4[0x54]](function(_0x63d3x3) {
                $(this)[__Ox4c7c4[0x53]](function() {
                    $(__Ox4c7c4[0x4d])[__Ox4c7c4[0x51]](_0x63d3x3)[__Ox4c7c4[0x50]]()
                }, function() {
                    $(__Ox4c7c4[0x4d])[__Ox4c7c4[0x51]](_0x63d3x3)[__Ox4c7c4[0x52]]()
                })
            })
        }
    },
    fixed: function() {
        if (window[__Ox4c7c4[0x3]][__Ox4c7c4[0x56]]) {
            var _0x63d3x9 = $(window[__Ox4c7c4[0x3]][__Ox4c7c4[0x56]])[__Ox4c7c4[0x58]]()[__Ox4c7c4[0x57]] - 80;
            $(__Ox4c7c4[0x4b])[__Ox4c7c4[0x59]]({
                scrollTop: _0x63d3x9
            }, 300)
        };
        $(window)[__Ox4c7c4[0x5e]](function() {
            var _0x63d3xa = $(this);
            var _0x63d3xb = $(this)[__Ox4c7c4[0x5a]]();
            var _0x63d3xc = $(window)[__Ox4c7c4[0x5b]]();
            if (_0x63d3xb >= 50) {
                $(__Ox4c7c4[0x5d])[__Ox4c7c4[0x21]](__Ox4c7c4[0x5c])
            } else {
                $(__Ox4c7c4[0x5d])[__Ox4c7c4[0x28]](__Ox4c7c4[0x5c])
            }
        });
        $(window)[__Ox4c7c4[0x5e]](function() {
            var _0x63d3xa = $(this);
            var _0x63d3xb = $(this)[__Ox4c7c4[0x5a]]();
            var _0x63d3xc = $(window)[__Ox4c7c4[0x5b]]();
            if (_0x63d3xb >= 1200) {
                $(__Ox4c7c4[0x60])[__Ox4c7c4[0x21]](__Ox4c7c4[0x5f])
            } else {
                $(__Ox4c7c4[0x60])[__Ox4c7c4[0x28]](__Ox4c7c4[0x5f])
            }
        })
    },
    Search: function() {
        $(__Ox4c7c4[0x64])[__Ox4c7c4[0x63]](function() {
            $(__Ox4c7c4[0x62])[__Ox4c7c4[0x21]](__Ox4c7c4[0x61])
        });
        $(__Ox4c7c4[0x64])[__Ox4c7c4[0x65]](function() {
            $(__Ox4c7c4[0x62])[__Ox4c7c4[0x28]](__Ox4c7c4[0x61])
        })
    },
    wrapper: function() {
        var _0x63d3x8 = $(window)[__Ox4c7c4[0x49]]();
        if (_0x63d3x8 < 820) {
            $[__Ox4c7c4[0x48]](maccms[__Ox4c7c4[0x34]] + __Ox4c7c4[0x66], function() {
                $(__Ox4c7c4[0x68])[__Ox4c7c4[0x67]]();
                $(__Ox4c7c4[0x6a])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x69]
                });
                $(__Ox4c7c4[0x6c])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x6b]
                });
                $(__Ox4c7c4[0x6e])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x6d]
                });
                $(__Ox4c7c4[0x70])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x6f]
                });
                $(__Ox4c7c4[0x72])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x71]
                });
                $(__Ox4c7c4[0x74])[__Ox4c7c4[0x67]]({
                    SelectName: __Ox4c7c4[0x73]
                })
            })
        }
    },
    flip: function() {
        $(__Ox4c7c4[0x7b])[__Ox4c7c4[0x2b]](function() {
            $(__Ox4c7c4[0x77])[__Ox4c7c4[0x76]](__Ox4c7c4[0x75]);
            $(__Ox4c7c4[0x79])[__Ox4c7c4[0x78]]();
            $(__Ox4c7c4[0x7a])[__Ox4c7c4[0x78]]()
        })
    },
    closebtn: function() {
        $(__Ox4c7c4[0x7f])[__Ox4c7c4[0x2b]](function() {
            $(__Ox4c7c4[0x7c])[__Ox4c7c4[0x2a]]();
            $(__Ox4c7c4[0x7e])[__Ox4c7c4[0x28]](__Ox4c7c4[0x7d])
        });
        $(__Ox4c7c4[0x81])[__Ox4c7c4[0x2b]](function() {
            $(__Ox4c7c4[0x80])[__Ox4c7c4[0x2a]]()
        })
    },
    shorturl: function() {
        var _0x63d3xd = $(__Ox4c7c4[0x82]);
        var _0x63d3xe = $(__Ox4c7c4[0x83]);
        var _0x63d3xf = __Ox4c7c4[0x84];
        var _0x63d3x10 = $(__Ox4c7c4[0x86])[__Ox4c7c4[0x85]]();
        var _0x63d3x11 = $(__Ox4c7c4[0x87])[__Ox4c7c4[0x85]]();
        if (_0x63d3x11 == __Ox4c7c4[0x3a]) {
            var _0x63d3x12 = _0x63d3xf + __Ox4c7c4[0x88] + _0x63d3x10 + __Ox4c7c4[0x89] + encodeURIComponent(ikan[__Ox4c7c4[0x30]][__Ox4c7c4[0x8a]]);;;
        } else {
            var _0x63d3x12 = _0x63d3xf + __Ox4c7c4[0x88] + _0x63d3x10 + __Ox4c7c4[0x89] + _0x63d3x11 + encodeURIComponent(ikan[__Ox4c7c4[0x30]][__Ox4c7c4[0x8b]]);;;
        };
        $[__Ox4c7c4[0x91]]({
            url: _0x63d3x12,
            type: __Ox4c7c4[0x8c],
            dataType: __Ox4c7c4[0x8d],
            cache: false,
            success: function(_0x63d3x13, _0x63d3x14) {
                for (x in _0x63d3x13[__Ox4c7c4[0x8f]][__Ox4c7c4[0x8e]][0x0]) {;
                };
                _0x63d3xd[__Ox4c7c4[0x27]](_0x63d3x13[__Ox4c7c4[0x8f]][__Ox4c7c4[0x8e]][0x0][__Ox4c7c4[0x90]]);
                _0x63d3xe[__Ox4c7c4[0x27]](_0x63d3x13[__Ox4c7c4[0x8f]][__Ox4c7c4[0x8e]][0x0][__Ox4c7c4[0x90]]);
            }
        })
    },
    images: {
        lazyload: function() {
            $[__Ox4c7c4[0x48]](maccms[__Ox4c7c4[0x34]] + __Ox4c7c4[0x92], function() {
                $(__Ox4c7c4[0x95])[__Ox4c7c4[0x94]]({
                    effect: __Ox4c7c4[0x93],
                    threshold: 200,
                    failurelimit: 20
                });
                var _0x63d3x8 = $(window)[__Ox4c7c4[0x49]]();
                if (_0x63d3x8 < 820) {
                    $(__Ox4c7c4[0x96])[__Ox4c7c4[0x28]](__Ox4c7c4[0x94]);
                    $(__Ox4c7c4[0x96])[__Ox4c7c4[0x21]](__Ox4c7c4[0x97]);
                    $(__Ox4c7c4[0x99])[__Ox4c7c4[0x94]]({
                        effect: __Ox4c7c4[0x93],
                        threshold: 150,
                        failurelimit: 5,
                        container: $(__Ox4c7c4[0x98])
                    })
                }
            })
        },
        qrcode: function() {
            $[__Ox4c7c4[0x48]](maccms[__Ox4c7c4[0x34]] + __Ox4c7c4[0x9a], function() {
                $(__Ox4c7c4[0x9c])[__Ox4c7c4[0x9b]]({
                    width: 120,
                    height: 120,
                    text: encodeURI(ikan[__Ox4c7c4[0x30]][__Ox4c7c4[0x8a]])
                });

                function _0x63d3x15(_0x63d3x16) {
                    var _0x63d3x17 = new Image();
                    _0x63d3x17[__Ox4c7c4[0x9d]] = _0x63d3x16[__Ox4c7c4[0x9f]](__Ox4c7c4[0x9e]);
                    return _0x63d3x17
                }
                var _0x63d3x18 = $(__Ox4c7c4[0x11])[0x0];
                var _0x63d3x19 = _0x63d3x15(_0x63d3x18);
                $(__Ox4c7c4[0xa0])[__Ox4c7c4[0x27]](_0x63d3x19)
            })
        }
    },
    scrolltop: function() {
        var _0x63d3x5 = $(window);
        $scrollTopLink = $(__Ox4c7c4[0xa1]);
        _0x63d3x5[__Ox4c7c4[0x5e]](function() {
            500 < $(this)[__Ox4c7c4[0x5a]]() ? $scrollTopLink[__Ox4c7c4[0x3e]](__Ox4c7c4[0xa2], __Ox4c7c4[0xa3]) : $scrollTopLink[__Ox4c7c4[0x3e]](__Ox4c7c4[0xa2], __Ox4c7c4[0xa4])
        });
        $scrollTopLink[__Ox4c7c4[0xa6]](__Ox4c7c4[0x2b], function() {
            $(__Ox4c7c4[0xa5])[__Ox4c7c4[0x59]]({
                scrollTop: 0
            }, 400);
            return !1
        })
    },
    copy: function() {
        $[__Ox4c7c4[0x48]](maccms[__Ox4c7c4[0x34]] + __Ox4c7c4[0xa7], function() {
            var _0x63d3x1a = document[__Ox4c7c4[0xa9]](__Ox4c7c4[0xa8]);
            var _0x63d3x1b = new ClipboardJS(_0x63d3x1a);
            _0x63d3x1b[__Ox4c7c4[0xa6]](__Ox4c7c4[0xaa], function(_0x63d3x1c) {
                $(__Ox4c7c4[0xae])[__Ox4c7c4[0xad]]()[__Ox4c7c4[0xac]](1500)[__Ox4c7c4[0xab]](300);
                console[__Ox4c7c4[0xaf]](_0x63d3x1c)
            });
            _0x63d3x1b[__Ox4c7c4[0xa6]](__Ox4c7c4[0xb0], function(_0x63d3x1c) {
                $(__Ox4c7c4[0xae])[__Ox4c7c4[0xad]]()[__Ox4c7c4[0xac]](1500)[__Ox4c7c4[0xab]](300);
                console[__Ox4c7c4[0xaf]](_0x63d3x1c)
            })
        })
    },
    wxqrcode: function() {
        var _0x63d3x1d = $(__Ox4c7c4[0xb1])[__Ox4c7c4[0x85]]();
        var _0x63d3x1e = $(__Ox4c7c4[0xb2])[__Ox4c7c4[0x85]]();
        var _0x63d3x1f = $(__Ox4c7c4[0xb3])[__Ox4c7c4[0x85]]();
        $(__Ox4c7c4[0xb9])[__Ox4c7c4[0x2b]](function() {
            $(__Ox4c7c4[0x8])[__Ox4c7c4[0x27]](__Ox4c7c4[0xb4] + _0x63d3x1e + __Ox4c7c4[0xb5] + _0x63d3x1d + __Ox4c7c4[0xb6]);
            $(__Ox4c7c4[0xb8])[__Ox4c7c4[0x2b]](function() {
                $(__Ox4c7c4[0xb7])[__Ox4c7c4[0x2a]]()
            })
        });
        $(__Ox4c7c4[0xbe])[__Ox4c7c4[0x2b]](function() {
            $(__Ox4c7c4[0x8])[__Ox4c7c4[0x27]](__Ox4c7c4[0xba] + _0x63d3x1f + __Ox4c7c4[0xbb]);
            $(__Ox4c7c4[0xbd])[__Ox4c7c4[0x2b]](function() {
                alert(__Ox4c7c4[0xbc]);
                $(__Ox4c7c4[0xb7])[__Ox4c7c4[0x2a]]()
            });
            $(__Ox4c7c4[0xb8])[__Ox4c7c4[0x2b]](function() {
                $(__Ox4c7c4[0xb7])[__Ox4c7c4[0x2a]]()
            })
        })
    }
};
$(document)[__Ox4c7c4[0xcd]](function() {
    ikan[__Ox4c7c4[0x30]][__Ox4c7c4[0x2f]][__Ox4c7c4[0xbf]] && (ikan[__Ox4c7c4[0xbf]][__Ox4c7c4[0xc0]](), ikan[__Ox4c7c4[0xbf]][__Ox4c7c4[0xc1]]());
    ikan[__Ox4c7c4[0xc2]]();
    ikan[__Ox4c7c4[0xc3]]();
    ikan[__Ox4c7c4[0xc4]]();
    ikan.Search();
    ikan[__Ox4c7c4[0xc5]]();
    ikan[__Ox4c7c4[0xc6]]();
    ikan[__Ox4c7c4[0xc7]]();
    ikan[__Ox4c7c4[0xc8]]();
    ikan[__Ox4c7c4[0xc9]][__Ox4c7c4[0x94]]();
    ikan[__Ox4c7c4[0xc9]][__Ox4c7c4[0x9b]]();
    ikan[__Ox4c7c4[0xca]]();
    ikan[__Ox4c7c4[0xcb]]();
    ikan[__Ox4c7c4[0xcc]]()
})