<?php
function ekeke($str)
{
$str=unescape($str);
return $str;
}
?>