<?php
$app_ftp = '0';
$app_ftphost = 'test.seacms.net';
$app_ftpuser = 'seacmstest';
$app_ftppass = 'seacmstest';
$app_ftpport = '21';
$app_ftpdir = '/';
$app_ftpurl = 'https://img3.doubanio.com/view/photo/s_ratio_poster/public';
$app_ftpdel = '0';
$app_updatepic = '1';
?>