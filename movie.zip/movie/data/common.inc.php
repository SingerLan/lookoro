<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'xmelhguw';
$cfg_dbuser = 'xmelhguw';
$cfg_dbpwd = 'l42h38ZPop';
$cfg_dbprefix = 'sea_';
$cfg_db_language = 'utf8';
?>